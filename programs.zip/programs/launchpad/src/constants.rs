// programs/launchpad_pool/src/constants.rs
pub const USDC_MINT_PUBKEY: &str = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v";
pub const USDT_MINT_PUBKEY: &str = "BS2oxuSzEscqnLEtDBQB44G5h8mZsBp7HBTUQkZSbhHD";
pub const ADMIN_PUBKEY: &str = "Kw989nLx9N4FV5rtwmJzrQVigr888dPpVqqV"; 